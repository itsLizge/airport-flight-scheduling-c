//
//
//

#include "flight.h"
#include <time.h>
#include <string.h>
#include <stdlib.h>
//This function will create a dynamically allocated flight with random values and return its address.
Flight * createRandomFlight(int maxReadyTime, int maxServiceTime){
    char *airlines[]={"AQ","DM","BJ","RL","GB","ZA","VX","JP","ML","VF","DW","SU","SM","KJ","YE","VJ","QH","HD","UJ","EI","EG","RV","ZI","KI","QB","LD","UX","NX","HM","CY","AA","AZ","EK","ED","ZW","YI","GN","ZB"};
    char *destination[]={"JYH","DWI","ABJ","ABG","ABX","CYD","AES","ADR","AEK","TKJ","UCR","AFL","AAW","AAZ","ACQ","AFF","FLA","ADO","LMU","EIN","EUK","ROU","AAF","AAG","AAJ","AHK","AEA","AMU","SEY","LCA","MAP","CAI","MCM","AXE","AWI","RSI","AGN","ABN"};
    Flight *flight;
    flight=(Flight*)malloc(sizeof( Flight));
    if(flight==NULL){
        return NULL;
    }
    int random_type= 1 + rand()%3;
    if(random_type==1){
        flight->flightType='D';
    }else if(random_type==2){
        flight->flightType='I';
    }else if(random_type==3){
        flight->flightType='E';
    }
    flight->readyTime=( rand() % maxReadyTime)+ 1;
    flight->serviceTime=(rand() % maxServiceTime )+ 1;
    flight->serviceStartTime=0;
    flight->runwayNumber=0;
    strncpy(flight->airline,airlines[rand()%38],3);
    strncpy(flight->destination,destination[rand()%38],4);

    return flight;
}

//This function gets a flights address and prints its values.
void printFlightInformation(Flight* flight){
    if(flight != NULL){
        printf("%c %2d %2d %2d %2d %3s %4s\n", flight->flightType, flight->readyTime, flight->serviceTime, flight->serviceStartTime, flight->runwayNumber, flight->airline, flight->destination);
    }
}
