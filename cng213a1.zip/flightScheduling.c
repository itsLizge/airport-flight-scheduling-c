#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "list.h"
#include "queue.h"

// To parse input from program arguments
void parseInput(char **, int *, int *, int *, int *);

// To initialise, create and populate the flight mylist with random flight data
List createFlightList(int, int, int);

//To initialise myqueue of the arrived flights and runway availability data
int* initialiseSimulator(Queue*, int);

//Adds the arrived flight into the priority myqueue
void newFlight(Flight*, Queue);

//Randomly assign an available runway to the flight
void serveFlight(Flight*, int*, int);

//Print the statistical data of the simulation run
void reportStatistics(List, int, int, int);

//Clear dynamically allocated memories
void exitFromTheSimulation(List, Queue, int *);

int main(int argc, char *argv[])
{  if(argc!=5){
        fprintf(stderr,"%s <numberOfFlights> <numberOfRunways> <maxReadyTime> <maxServiceTime>\n",argv[0]);
        return 1;
}
    srand(time(NULL));
    int numberOfFlights,numberOfRunways,maxReadyTime,maxServiceTime;
    int clock=0;
    int servedFlights=0;
    int *runwayAvailability;
    int *runwayFinishTime;

    List flightList=NULL;
    Queue flightQueue=NULL;
    List recordList=NULL;

    parseInput(argv,&numberOfFlights,&numberOfRunways,&maxReadyTime,&maxServiceTime);
    flightList= createFlightList(numberOfFlights,maxReadyTime,maxServiceTime);
    runwayAvailability= initialiseSimulator(&flightQueue,numberOfRunways);
     recordList=CreateList();
    if(flightQueue==NULL || flightList==NULL || runwayAvailability==NULL){
        printf("initializing failed.\n");
        return 1;
    }

    runwayFinishTime=(int *) malloc(numberOfRunways * sizeof(int));
    if(runwayFinishTime==NULL){
        printf("allocation failed.\n");
        return 1;
    }
    //until  all flights departure from runways
    while(servedFlights<numberOfFlights){
        //make departure and make the runway available

        for(int i=0; i<numberOfRunways;i++){
            if(runwayAvailability[i]==0 && clock>= runwayFinishTime[i]){
                runwayAvailability[i]=1;
                servedFlights++;
            }
        }
        //when a new flight comes
        while (!IsEmptyList(flightList) && HeadOfList(flightList)->readyTime <=clock){
            Flight *comingFlight= DeleteFirstNode(flightList);//remove from the list
            newFlight(comingFlight,flightQueue);//add it to queue by its priority

        }
        //check if there is flight waiting in the queue
        while(!IsEmptyQueue(flightQueue)){
            //find available runway
            int availability=-1;
            for(int i=0;i<numberOfRunways;i++){
                if(runwayAvailability[i]==1){
                    availability=i;
                }
            }
            //if we found an available runway
            if(availability!=-1){
                Flight *departureFlight= Dequeue(flightQueue);

                departureFlight->serviceStartTime=clock;
                //make runway busy and assign runway number
                serveFlight(departureFlight,runwayAvailability,availability);
                //calculate when runway will be empty
                runwayFinishTime[availability]=clock + departureFlight->serviceTime;
                InsertListOrderedByReadyTime(recordList,departureFlight);
            }else//no available runway
                break;
        }
        //if there is still flights in the queue
        if(servedFlights < numberOfFlights){
            int nextFLightTime=-1;
            if(!IsEmptyList(flightList)){//next flight ready time in the list
                nextFLightTime= HeadOfList(flightList)->readyTime;
            }
            for(int j=0; j<numberOfRunways;j++){
                if(runwayAvailability[j]==0){//if it is busy
                    if(nextFLightTime==-1 || runwayFinishTime[j]<nextFLightTime)
                        nextFLightTime=runwayFinishTime[j];
                }
            }
            if(nextFLightTime!=-1){
                if(nextFLightTime>clock)
                    clock=nextFLightTime;
                else
                    clock++;
            }else
                clock++;
        }
    }

    reportStatistics(recordList,numberOfRunways,numberOfFlights,clock);
    exitFromTheSimulation(flightList,flightQueue,runwayAvailability);
    deleteList(recordList);
    free(runwayFinishTime);

    return 0;
}

void parseInput(char *programArguments[], int *noOfFlights, int *noOfRunways, int *maxReadyTime, int *maxServiceTime){
    if(programArguments[1]!=NULL)
        *noOfFlights= atoi(programArguments[1]);
    if(programArguments[2]!=NULL)
        *noOfRunways= atoi(programArguments[2]);
    if(programArguments[3]!=NULL)
        *maxReadyTime= atoi(programArguments[3]);
    if(programArguments[4]!=NULL)
        *maxServiceTime= atoi(programArguments[4]);
}

List createFlightList(int numberOfFlights, int maxReadyTime, int maxServiceTime){
    List flightList=CreateList();
    if(flightList==NULL){
        printf("allocation failed.\n");
        return NULL;
    }

    for(int i=0 ; i<numberOfFlights;i++ ){
        Flight *newFlight= createRandomFlight(maxReadyTime,maxServiceTime);
        if(newFlight==NULL){
            printf("allocation failed..\n");
            break;
        }
        InsertListOrderedByReadyTime(flightList,newFlight);
    }
    return flightList;
}

int* initialiseSimulator(Queue* flightQueue, int noOfRunways){
    //creating queue
    *flightQueue=CreateQueue();
    MakeEmptyQueue(*flightQueue);
    //array to keep the availability of the runways
    int *runwayAvailability=(int*) malloc(noOfRunways*sizeof(int));
    if(runwayAvailability==NULL){
        printf("allocation failed\n");
        return NULL;
    }
    //queue is empty make the runways' availability 1
    for(int i=0;i<noOfRunways;i++){
        runwayAvailability[i]=1;
    }
    return runwayAvailability;
}

void newFlight(Flight* flightData,Queue flightQueue){
    if(flightQueue!=NULL || flightData!=NULL){
        Enqueue(flightData,flightQueue);
    }else
        return;
}

// int *runways is the runway array
void serveFlight(Flight* flightData, int* runways, int runwayNumber){
    if(flightData==NULL){
        return;
    }
    //runway which we are using is busy now
    runways[runwayNumber]=0;
    //assigning a runway number to our flight
    flightData->runwayNumber=runwayNumber +1;

}

void reportStatistics(List flightsDataList, int noOfRunways, int numberOfFlights, int clockTime){
    if(flightsDataList==NULL || numberOfFlights==0)
        return;

    int countEmergency=0;
    int countInternational=0;
    int countDomestic=0;
    int totalWait=0;
    int maxWait=0;
    int runway1=0;
    int runway2=0;
    double average;
    int waitingTime;
    struct ListNode *current=flightsDataList->head->next;

    while(current!=NULL){
        Flight *flight=current->flightInformation;

        if(flight->flightType=='E')
            countEmergency++;
        else if(flight->flightType=='I')
            countInternational++;
        else if(flight->flightType=='D')
            countDomestic++;

        waitingTime=flight->serviceStartTime - flight->readyTime;
        totalWait+=waitingTime;
        if(waitingTime>maxWait)
            maxWait=waitingTime;

        if(flight->runwayNumber==1)
            runway1++;
        else if(flight->runwayNumber==2)
            runway2++;

        current=current->next;
    }

    average=((double)totalWait)/numberOfFlights;

    printf("********Report**********\n");
    printf("The number of runways: %d\n",noOfRunways);
    printf("The number of flights: %d\n",numberOfFlights);
    printf("Number of flights for each flight type:\n\tEmergency: %d\n\tInternational: %d\n\tDomestic: %d\n",countEmergency,countInternational,countDomestic);
    printf("Number of flights for each runway:\n\tRunway 1: %d\n\tRunway 2: %d\n",runway1,runway2);
    printf("Completion time: %d\n",clockTime);
    printf("Average time spent in the queue: %.1lf\n",average);
    printf("Maximum waiting time: %d\n",maxWait);
    printf("Popular airline: \n");
    printf("Popular destination: \n");
}

void exitFromTheSimulation(List flightList, Queue flightQueue, int *flightData){
    if(flightQueue!=NULL)
        deleteQueue(flightQueue);
    if(flightList!=NULL)
        deleteList(flightList);
    if(flightData!=NULL)
        free(flightData);
}