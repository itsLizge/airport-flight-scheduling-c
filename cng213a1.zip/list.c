//
//
//
#include <stdlib.h>
#include <stdio.h>
#include "list.h"

List CreateList()
{
    List myList;
    myList=(List)malloc(sizeof(struct ListRecord));
    if(myList==NULL){
        printf("allocation failed.\n");
        return NULL;
    }
    MakeEmptyList(myList);
    return myList;
}

void MakeEmptyList(List l)
{
    struct ListNode *dummy= malloc(sizeof (struct ListNode));
    if(dummy==NULL){
        printf("allocation failed\n");
        return;
    }
    dummy->next=NULL;
    l->head=dummy;
    l->tail=dummy;
    l->length=0;
}

void InsertList(List l, int pos, Flight* data)
{
    if(pos> ListSize(l))
        pos= ListSize(l)+1;
    if(pos== ListSize(l)+1)
        InsertToListEnd(l,data);
    else
        InsertListOrderedByReadyTime(l,data);

    l->length++;
}

void InsertToListEnd(List l, Flight* flight){
    struct ListNode *insert= malloc(sizeof (struct ListNode));
    insert->flightInformation=flight;
    insert->next=NULL;
    l->tail->next=insert;
    l->tail=insert;

}

void InsertToListHead(List l, Flight* flight){
    struct ListNode *insert= malloc(sizeof (struct ListNode));
    if(insert==NULL)
        return;
    insert->flightInformation=flight;
    insert->next=l->head->next;
    l->head->next=insert;
    if(l->tail==l->head)
        l->tail=insert;

}

void InsertListOrderedByReadyTime(List l, Flight* newFlight){
    struct ListNode *new=(struct ListNode*) malloc(sizeof (struct ListNode));
    if(new==NULL){
        printf("allocation failed.\n");
        return;
    }
    new->flightInformation=newFlight;
    new->next=NULL;

    struct ListNode *current=l->head;
    while(current->next != NULL && newFlight->readyTime >= current->next->flightInformation->readyTime){
        current=current->next;
    }
    new->next=current->next;
    current->next=new;

    //if it is at the end update tail
    if(new->next==NULL){
        l->tail=new;
    }
    l->length++;
}

Flight* DeleteFirstNode(List l){
    if(l->head->next!=NULL) {
        struct ListNode *delete = l->head->next;
        Flight *deletedData=delete->flightInformation;
        l->head->next = delete->next;
        // if deleted data was the tail
        if(delete==l->tail)
            l->tail=l->head;
        free(delete);
        l->length--;
        return deletedData;
    }else{
        printf("list is empty!\n");
        return NULL;
    }
}

void DeleteFromList(List l, Flight* v)
{
    if(IsEmptyList(l)){
        printf("list is already empty!\n");
        return;
    }
    struct ListNode *current=l->head->next;
    Flight *data=current->next->flightInformation;
    while(data!=v){
        current=current->next;
        data=current->flightInformation;
    }
    if(current->next==NULL){
        printf("flight not found in the mylist.\n");
        return;
    }else{
        struct ListNode *delete;
        delete=current->next;
        current->next=current->next->next;
        if(delete->next==NULL){
            l->tail=current;
        }
        free(delete);
        l->length--;
    }

}

int IsEmptyList(List l)
{
    if(l->length==0)
        return 1;
    else
        return 0;
}

int ListSize(List l)
{
    return l->length;
}

Flight* HeadOfList(List l)
{
    if(!IsEmptyList(l)) {
        return (l->head->next->flightInformation);
    }
    else {
        printf("list is empty!\n");
        return NULL;
    }
}

Flight* TailOfList(List l)
{
    if(!IsEmptyList(l)){
        return (l->tail->flightInformation);
    }
    else{
        printf("list is empty\n");
        return NULL;
    }
}

void DisplayList(List l)
{
    if(IsEmptyList(l)){
        printf("list is empty!\n");
        return;
    }
    struct ListNode *current=l->head->next;

    while (current!=NULL){
        printf("\nFlight Type\tReady Time\tService Time\tService Start Time\tRunway Number\tAirline\tDestination\n");
        printf("\t%c\t%d\t%d\t%d\t%d\t%s\t%s\n",current->flightInformation->flightType,current->flightInformation->readyTime,current->flightInformation->serviceTime,current->flightInformation->serviceStartTime,current->flightInformation->runwayNumber,current->flightInformation->airline,current->flightInformation->destination);
        current=current->next;
    }
}

void deleteList(List toDeleteList)
{
    if(IsEmptyList(toDeleteList)){
        printf("list is empty!\n");
        return;
    }
    struct ListNode *delete= toDeleteList->head;
    struct ListNode *next;

    while (delete!=NULL){
        next=delete->next;
        free(delete);
        delete=next;
    }
    free(toDeleteList);
    printf("List is deleted!!\n");
}
