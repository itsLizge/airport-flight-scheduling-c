//
//
//

#ifndef mylist
#define mylist
#include <stdio.h>
#include <stdlib.h>
#include "flight.h"

// Linked mylist implementation will be responsible for Flight* allocations and deallocation

// A structure to represent a mylist node with item type Flight*
struct ListNode
{
    Flight *flightInformation;
    struct ListNode *next;
};

// A structure to keep a linked mylist record
struct ListRecord
{
    struct ListNode *head;
    struct ListNode *tail;
    int length;
};

// Typedef for mylist record pointer
typedef struct ListRecord *List;

/* A function to create a mylist, it allocates an address in
 * memory for ListRecord and creates an empty linked mylist with dummy
 * node by using MakeEmptyList function.*/
List CreateList(void);

// Makes a mylist empty with dummy node.
void MakeEmptyList(List);

// Insert a node to a specific position of the linked mylist
void InsertList(List, int, Flight*);

// Insert to the end of linked mylist
void InsertToListEnd(List, Flight*);

//Insert to the beginning of the linked mylist
void InsertToListHead(List, Flight*);

//Insert to linked mylist by ready time order (Ascending, smallest ready time at Head)
void InsertListOrderedByReadyTime(List l, Flight*);

//To delete first node from the linked mylist and return the address of deleted nodes item Flight
Flight* DeleteFirstNode(List);

//To Delete a flight from the mylist
void DeleteFromList(List, Flight*);

//To get the length of the linked mylist
int ListSize(List);

//To get the Flights address at the head of the linked mylist, without removing the node!
Flight* HeadOfList(List);

//To get the Flight address at the tail of the linked mylist, without removing the node!
Flight* TailOfList(List);

//To check of mylist is empty, 1 for empty, 0 for not
int IsEmptyList(List);

//To print the content of the linked mylist
void DisplayList(List);

//To free all the nodes and delete the linked mylist
void deleteList(List);


#endif //
