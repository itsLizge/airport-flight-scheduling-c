
#include <stdio.h>
#include <stdlib.h>
#include "queue.h"


Queue CreateQueue()
{   Queue myQueue;
    myQueue=(Queue)malloc(sizeof(struct QueueRecord));
    if(myQueue==NULL){
        printf("allocation failed.\n");
        return NULL;
    }
    MakeEmptyQueue(myQueue);
    return myQueue;
}

void MakeEmptyQueue(Queue q)
{
    if (q == NULL) return;

    struct QueueNode* dummyNode = (struct QueueNode*)malloc(sizeof(struct QueueNode));
    if (dummyNode == NULL) {
        printf("Dummy Node allocation failed.\n");
        return;
    }

    dummyNode->flightInfo = NULL;
    dummyNode->priority = -1;
    dummyNode->next = NULL;

    q->front = dummyNode;
    q->rear = dummyNode;
    q->size = 0;

}

void Enqueue(Flight* newFlight, Queue q)
{
    int priority;
    if(newFlight->flightType=='E')
        priority=3;
    else if(newFlight->flightType=='I')
        priority=2;
    else
        priority=1;

    struct QueueNode *new= malloc(sizeof (struct QueueNode));
    if(new==NULL)
        return;
    new->flightInfo=newFlight;
    new->priority=priority;
    new->next=NULL;

    //if queue is empty in the beginning
    if(q->front==NULL){
        q->front=new;
        q->rear=new;
        q->size++;
        return;
    }
    struct QueueNode *current=q->front;
    while (current->next!=NULL && new->priority <= current->next->priority){
        current=current->next;
    }
    new->next=current->next;
    current->next=new;

    if(new->next==NULL){
        q->rear=new;
    }

    q->size++;
}


Flight* Dequeue(Queue q)
{
    if(IsEmptyQueue(q)){
        return NULL;
    }
    struct QueueNode *remove;
    remove=q->front->next;
    Flight *flight=remove->flightInfo;
    q->front->next=remove->next;
    //if the removed node was the last node
    if(q->front->next==NULL){
        q->rear=q->front;
    }

    free(remove);
    q->size--;
    return flight;
}

int IsEmptyQueue(Queue q)
{
    if(q->size==0){
        return 1;
    }else
        return 0;
}

int QueueSize(Queue q)
{
    return q->size;
}

Flight* FrontOfQueue(Queue q)
{
    if(!IsEmptyQueue(q)) {
        return q->front->next->flightInfo;
    }else{
        printf("myqueue is empty.\n");
        return NULL;
    }
}

Flight* RearOfQueue(Queue q)
{
    if(!IsEmptyQueue(q)){
        return q->rear->flightInfo;
    }else {
        printf("myqueue is empty!\n");
        return NULL;
    }
}

void DisplayQueue(Queue q)
{
    if(!IsEmptyQueue(q)){
        struct QueueNode *tmp=q->front->next;
        while(tmp!=NULL){
            printFlightInformation(tmp->flightInfo);
            tmp=tmp->next;
        }
    }else{
        printf("myqueue is empty!\n");
    }
}

void deleteQueue(Queue toDeleteList)
{
    if(IsEmptyQueue(toDeleteList)){
        printf("myqueue is already empty!\n");
        return;
    }
    while (!IsEmptyQueue(toDeleteList)){
        Dequeue(toDeleteList);
    }
    //deletes dummy node
    if(toDeleteList->front!=NULL){
        free(toDeleteList->front);
    }
    free(toDeleteList);

    printf("Queue is deleted!\n");

}
