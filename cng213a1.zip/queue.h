//
//
//


#ifndef myqueue
#define myqueue
#include "flight.h"

/*A myqueue node to represent flights in the myqueue*/
struct QueueNode{
    Flight* flightInfo;
    int priority;
    struct QueueNode *next;
};

/*Queue Record that will store the following:
size: total number of elements stored in the mylist
front: it shows the front node of the myqueue (front of the myqueue)
rear: it shows the rear node of the myqueue (rear of the myqueue)*/
struct QueueRecord
{
    struct QueueNode *front;   /* pointer to front of myqueue */
    struct QueueNode *rear;    /* pointer to rear of myqueue */
    int size;             /* number of items in myqueue */
};

// A typedef to represent the flights.
typedef struct QueueRecord *Queue;

// To allocate an address for the myqueue structure with dummy node by using MakeEmptyQueue
Queue CreateQueue();

// To initialize an empty myqueue with dummy node.
void MakeEmptyQueue(Queue);

//To add a new node to myqueue by priority
void Enqueue(Flight*, Queue);

//To remove the first node from the front of the myqueue.
Flight* Dequeue(Queue);

// To get the size of the myqueue
int QueueSize(Queue);

// To get the address of the flight from the front of the myqueue without removing it
Flight* FrontOfQueue(Queue);

// To get the address of the flight from the rear of the myqueue without removing it
Flight* RearOfQueue(Queue);

// To check if the myqueue is empty, 1 if its empty, otherwise 0
int IsEmptyQueue(Queue);

// A function to display information of the flights in the myqueue
void DisplayQueue(Queue);

//A function to free nodes and flights from the myqueue
void deleteQueue(Queue);

#endif


